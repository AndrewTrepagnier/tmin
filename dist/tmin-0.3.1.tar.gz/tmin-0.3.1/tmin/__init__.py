from .core import PIPE

__all__ = ['PIPE']
